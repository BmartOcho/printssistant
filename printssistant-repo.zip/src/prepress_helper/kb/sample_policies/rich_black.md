
# Rich Black Policy (Sample)

- Use rich black for large areas and headlines only.
- Recipe: 50C / 40M / 40Y / 100K (shop default).
- Body text ≤ 18pt must be 100K only and **overprint**.

Rationale: Improves depth without TAC issues; ensures small text stays sharp.
